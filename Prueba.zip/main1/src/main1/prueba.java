package main1;
import java.util.Scanner;
public class prueba {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner (System.in);
		
		int A[],B[];
		int ta,v1,v2,pro=0,sum1=0,sum2=0;
		double Pmod,z=0,mod1=0,mod2=0;
		System.out.println("Ingrese tamaño de los arreglo");
		ta=sc.nextInt();
		A=new int[ta];
		B=new int[ta];		
		for (int i=0; i<ta;i++) {
			System.out.println("ARREGLO A");
			System.out.println("Ingrese valor "+(i+1)+ " :");
			v1=sc.nextInt();
			A[i]=v1;
			sum1=(int)(sum1+Math.pow(A[i], 2));
		}
		
		for(int i=0;i<ta;i++) {
			System.out.println("ARREGLO B");
			System.out.println("Ingrese valor "+(i+1)+ " :");
			v2=sc.nextInt();
			B[i]=v2;
			sum2=(int)(sum1+Math.pow(B[i], 2));
		}
		mod1=(double)Math.sqrt(sum1);
		mod2=(double)Math.sqrt(sum2);
		Pmod=mod1*mod2;
		
		for (int i=0; i<ta;i++) {
			pro=pro+(A[i]*B[i]);
			
		}
		
		z=pro/Pmod;
		System.out.println("Producto punto:" +pro);
		System.out.println("Z = " +z);
		
		

	}

}
